from .model import Linknet
