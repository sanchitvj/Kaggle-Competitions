📈 Metrics
==========

Functional metrics
~~~~~~~~~~~~~~~~~~
.. automodule:: segmentation_models_pytorch.metrics.functional
        :members:
        :autosummary:
